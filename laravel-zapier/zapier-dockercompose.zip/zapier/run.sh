#!/bin/sh

# Run initial Laravel commands
php artisan migrate
php artisan passport:keys
php artisan optimize:clear

# Clear cache, routes, and configuration
php artisan cache:clear
php artisan route:clear
php artisan config:clear

# Install/update L5Swagger package
#composer require "darkaonline/l5-swagger"
#php artisan vendor:publish --provider="L5Swagger\L5SwaggerServiceProvider"

#php artisan vendor:publish --provider="L5Swagger\L5SwaggerServiceProvider" --tag=config

# Append the 'bearer_token' configuration using sed
# sed -i "/'sanctum'/a \ \ \ \ \ \ \ \ \ 'bearer_token' => [
#                     'type' => 'http',
#                     'description' => 'Authorization token obtained from logging in.',
#                     'name' => 'Authorization',
#                     'in' => 'header',
#                     'scheme' => 'bearer',
#                 ]," config/l5-swagger.php

# Clear cache, routes, and configuration after publishing assets
php artisan cache:clear
php artisan route:clear
php artisan config:clear

# Generate Swagger documentation
#php artisan l5-swagger:generate

# Generate Passport client
#php artisan passport:client --personal --name="client"

<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RestHooksController;
use App\Http\Controllers\InboundWebhookController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('/me', function () {
    return response()->json([
        'id' => auth()->user()->id,
        'name' => auth()->user()->name,
        'email' => auth()->user()->email
    ]);
})->middleware(['auth:api']);





Route::group(['middleware' => ['auth:api']], function () {
    Route::post('hooks', [RestHooksController::class, 'subscribe']);
    Route::delete('hooks/{id}', [RestHooksController::class, 'delete']);
    Route::get('polling/trigger', [RestHooksController::class, 'pollForTrigger']);
    Route::post('/inbound/webhook', [InboundWebhookController::class, 'handle']);
});



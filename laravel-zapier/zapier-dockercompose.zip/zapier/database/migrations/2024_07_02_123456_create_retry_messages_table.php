<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRetryMessagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('retry_messages', function (Blueprint $table) {
            $table->id();
            $table->text('message')->nullable(); // Nullable message column
            $table->integer('retry_count')->default(0);
            $table->text('processed')->default('false'); // Default value 'false' for processed
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('retry_messages');
    }
}


<?php

return [
	'APP_NAME' => env('APP_NAME'),
	'Authorization' => env('Authorization'),
	'AIRFLOW_NAME' => env('AIRFLOW_NAME'),
	'Airflow_Auth' => env('Airflow_Auth'),  // Airflow url
	'Woocommerce_Sid'=>env('Woocommerce_Sid'),
	'Woocommerce_Start_Date'=>'2001-01-01',
	'Postgress_Did'=> env('Postgress_Did'),
	'Shopify_Sid'=>env('Shopify_Sid'),
	'Woocommerce_Start_Date'=>env('Woocommerce_Start_Date'),
	'Postgres_Username'=> env('Postgres_Username'),
	'Postgres_Password'=> env('Postgres_Password'),
	'Postgres_Database'=> env('Postgres_Database'),
	'Postgres_Schema'=> env('Postgres_Schema'),
	'Postgres_Port'=> env('Postgres_Port'),
	'Postgres_Host'=> env('Postgres_Host'),
	'Woocommerce_Git_Repo' =>env('Woocommerce_Git_Repo'),
	'Shopify_Git_Repo' =>env('Shopify_Git_Repo'),
	'GITLAB_DAG' =>env('GITLAB_DAG'),
	'GITLAB_TOKEN' => env('GITLAB_TOKEN'),
	'WORKSPACE_ID' => env('WORKSPACE_ID'),
	'CUSTUMER_CREATE_API' => env('CUSTUMER_CREATE_API'),
	'CUSTUMER_CREATE_APP' => env('CUSTUMER_CREATE_APP'),
	'EQUITY_BRIX_URL' => env('EQUITY_BRIX_URL')
];

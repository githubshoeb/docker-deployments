<?php
 
namespace App\Casts;
 
use Illuminate\Contracts\Database\Eloquent\CastsAttributes;
use Illuminate\Database\Eloquent\Model;
 
class Json implements CastsAttributes
{
    /**
     * Cast the given value.
     *
     * @param  array<string, mixed>  $attributes
     * @return array<string, mixed>
     */
    public function get($model, $key, $value, $attributes)
    {

      // var_dump($value);
       //var_dump($key);
      // exit();
        return json_encode($value, true);
        //return json_decode(str_replace('\\/', '/', $value), true);
    }
 
    /**
     * Prepare the given value for storage.
     *
     * @param  array<string, mixed>  $attributes
     */
    public function set($model, $key, $value, $attributes)
    {
        return json_encode($value ,JSON_UNESCAPED_SLASHES);
    }
}
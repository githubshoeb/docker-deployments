<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Event;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
        URL::forceScheme('https');
    //        Event::listen(function (\SocialiteProviders\Manager\SocialiteWasCalled $event) {
    //     $event->extendSocialite('azure', \SocialiteProviders\Azure\Provider::class);
    //    });
    Event::listen(function (\SocialiteProviders\Manager\SocialiteWasCalled $event) {
    $event->extendSocialite('azureadb2c', \SocialiteProviders\AzureADB2C\Provider::class);
});

    }
}

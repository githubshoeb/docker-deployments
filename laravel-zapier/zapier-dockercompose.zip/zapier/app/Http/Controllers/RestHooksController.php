<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Webhook;

class RestHooksController extends Controller {

    public function subscribe(Request $request) {
        $input = $request->all();
        $webhook = Webhook::create([
                    "tenant_id" => auth()->user()->id,
                    "url" => $input["target_url"],
                    "event" => $input["event"]
        ]);

        return $webhook;
    }



   public function delete($id) {
    $webhook = Webhook::find($id);
    $webhook->delete();

    return response()->json([
        "success" => "success"
    ]);
}

public function pollForTrigger(Request $request) {
    $input = $request->all();
    if (isset($input["event"]) && ($input["event"] == 'product' )) {
        return response()->json([ [
            "id" => 1,
            "title" => "Sample Product",
            "image" => "sample_image.jpg",
            "status" => "active",
            "body_html" => "<p>This is a sample product description.</p>",
            "created_at" => "2024-03-20T12:00:00Z",
            "updated_at" => "2024-03-20T12:00:00Z",
            "permalink" => "sample-product",
            "variants" => [
                [
                    "id" => 101,
                    "title" => "Variant 1",
                    "price" => 19.99,
                    "inventory_quantity" => 100
                ]
            ],
            "store_url" => "https://examplestore.com"
      ]  ]);
    } else if (isset($input["event"]) && ($input["event"] == 'order' )) {
        return response()->json([ [
            "id" => 1,
            "order_id" => "123456",
            "total_price" => "100.00",
            "name" => "Sample Order",
            "status" => "completed",
            "created_at" => "2024-03-29T08:00:00Z",
            "updated_at" => "2024-03-30T10:00:00Z",
            "price" => "50.00",
            "line_items" => [
                [
                    "id" => "1",
                    "title" => "Default Title",
                    "price" => "20",
                    "regular_price" => "40"
                ]
            ],
            "organizationId" => "Org123",
            "customer_id" => "Cust456",
            "accountid" => "Acc789"
       ] ]);
    } else if (isset($input["event"]) && ($input["event"] == 'account' )) {
        return response()->json([ [
            "id" => 1,
            "firstName" => "dev",
            "lastName" => "james",
            "investorName" => "Dev James",
            "phoneNumber" => "4561237890",
            "city" => "seattle",
            "state" => "Washington",
            "country" => "usa",
            "zipCode" => "98101",
            "email" => "example@test.com"
      ]  ]);
    } else if (isset($input["event"]) && ($input["event"] == 'lead' )) {
        return response()->json([ [
            "id" => 1,
            "first_name"=> "John",
            "last_name"=> "Doe",
            "phone_work" => "555-987-6543",
            "phone_cell" => "555-987-6543",
            "email_primary" => "john.doe@example.com",
            "company_name"=> "ABC Company",
            "street_address"=> "123 Main St",
            "city"=> "Anytown",
            "state"=> "California",
            "zip_postal"=> "12345",
            "connection_type"=> "Client",
            "category"=> "Retail",
            "company_phone"=> "555-555-5555",
            "industry"=> "Technology",
            "select_product"=> "Product A",
            "priority"=> "High",
            "estimate_value"=> "$100,000",
            "notes"=> "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
      ]  ]);
    } else if (isset($input["event"]) && ($input["event"] == 'contact' )) {
        return response()->json([ [
            "id" => 1,
            "First_Name"=> "John",
            "Last_Name"=> "Doe",
            "Email_address_primary"=> "john.doe@example.com",
            "Email_address_secondary"=> "johndoe@gmail.com",
            "Cell_Phone"=> "+1 (555) 123-4567",
            "Home_Phone"=> "+1 (555) 987-6543",
            "Work_Phone"=> "+1 (555) 555-1212",
            "Business_Title"=> "Marketing Manager",
            "Address_1"=> "123 Main St",
            "Address_2"=> "Apt 101",
            "Contact_City"=> "Anytown",
            "Contact_State"=> "California",
            "Contact_Zip_Postal_Code"=> "12345",
            "Contact_Country"=> "USA",
            "Company_Name"=> "ABC Company",
            "Website_URL"=> "http://www.abccompany.com",
            "Company_Address_1"=> "456 Business Blvd",
            "Company_Address_2"=> "Suite 200",
            "City"=> "Big City",
            "State"=> "New York",
            "Zip_Postal_Code"=> "54321",
            "Country"=> "USA",
            "Office_Phone"=> "+1 (555) 123-4567",
            "Industry_Segment"=> "Technology",
            "Display_Name"=> "JohnD",
            "Gender"=> "Male",
            "Date_of_Birth"=> "1980-01-01",
            "Age"=> 42,
            "Facebook_Profile"=> "https=>//www.facebook.com/johndoe",
            "Twitter_Profile"=> "https=>//twitter.com/johndoe",
            "LinkedIn_Profile"=> "https=>//www.linkedin.com/in/johndoe",
            "Instagram_Profile"=> "https=>//www.instagram.com/johndoe",
            "Location"=> "Anytown, California",
            "Bio_Description"=> "Passionate marketer with a love for technology.",
            "Interests"=> ["Marketing", "Technology", "Travel"]
       ] ]);
    }
}


  

}

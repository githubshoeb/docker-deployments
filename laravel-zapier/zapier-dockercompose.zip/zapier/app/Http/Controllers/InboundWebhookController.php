<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Account;

class InboundWebhookController extends Controller
{
    public function handle(Request $request)
    {
        // Retrieve the payload sent by Zapier
      $payload = $request->all();
      
      //return $payload['first_name'];
      switch ($payload['event']) {
            case 'account_created':
                $this->handleAccountCreated($payload);
                break;
            case 'product_created':
                $this->handleProductCreated($payload);
                break;
            case 'order_created':
                $this->handleOrderCreated($payload);
                break;
            default:
                // Unsupported event, log or handle accordingly
                \Log::warning('Unsupported event received from Zapier', $payload);
                break;
        }

        // Return a response to Zapier
        return response()->json(['message' => 'Webhook received successfully'], 200);
    }

    protected function handleAccountCreated($payload)
    {
        // Process account creation event
       // var_dump($payload);
       // exit();
         // Insert account data into the database
         if (1) {
             //return $payload;
        // Insert account data into the database
        Account::create([
        'first_name' => $payload['first_name'],
        'last_name' => $payload['last_name'],
        'investor_name' => $payload['investor_name'],
        'phone_number' => $payload['phone_number'],
        'city' => $payload['city'],
        'state' => $payload['state'],
        'zip_code' => $payload['zip_code'],
        'email' => $payload['email']
        // Add other fields as needed
    ]);
    } else {
        // Log error or handle missing data
        \Log::error('Missing account data in payload', $payload);
    }

        // Example: Send a welcome email to the new user
        // $userEmail = $payload['email'];
        // Mail::to($userEmail)->send(new WelcomeEmail());
    }

    protected function handleProductCreated($payload)
    {
        // Process product creation event
        \Log::info('Product created', $payload);

        // Example: Update product inventory or trigger related actions
    }

    protected function handleOrderCreated($payload)
    {
        // Process order creation event
        \Log::info('Order created', $payload);

        // Example: Fulfill the order, update inventory, or trigger related actions
    }
}

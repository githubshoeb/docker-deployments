<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;
use App\Models\User;

class AzurAuthController extends Controller {

    public function redirectToMicrosoft() {
        //return Socialite::driver('azure')->redirect();
        return Socialite::driver('azureadb2c')->redirect();
        
    }

    public function handleMicrosoftCallback() {
        $clientSecret = config('services.azureadb2c.client_secret');

        if (empty($clientSecret)) {
            abort(500, 'Azure client secret is not configured.');
        }

        try {
            // Retrieve user data from Microsoft Azure
            $user = Socialite::driver('azureadb2c')->user();
            // Check if the user already exists in your database
            $existingUser = User::where('email', $user->email)->first();

            if (!$existingUser) {
                // If the user doesn't exist, create a new user record
                $newUser = User::create([
                            'name' => $user->name ?: $user->given_name.' '.$user->family_name,
                            'email' => $user->email,
                            'azure_id' => $user->id,
                                // Add any additional fields you want to store
                ]);

                // Authenticate the newly created user
                auth()->login($newUser);

                // Redirect to a desired route or perform any other action
                return redirect()->route('dashboard');
            }

            // Authenticate the existing user
            auth()->login($existingUser);
            $intendedUrl = session()->get('url.intended');
            if ($intendedUrl) {
                return redirect($intendedUrl);
            }
            // Redirect to a desired route or perform any other action
            return redirect()->route('dashboard');
        } catch (\Exception $e) {
            // Handle any exceptions that may occur during the authentication process
            return abort(500, 'Failed to authenticate with Azure: ' . $e->getMessage());
        }
    }

}

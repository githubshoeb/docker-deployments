<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductsResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request) {
        $response = parent::toArray($request);
        if(isset($response['image'])&&gettype($response['image']) == 'string')
        $response['image'] = json_decode($response['image'],true);
        $response['image'] = json_decode($response['image'],true);
        $response['variants'] = json_decode($response['variants'],true);
        $response['custom_data'] = json_decode($response['custom_data'],true);
        $i =0;
        if(isset( $response['image'])  && $response['image'] != 'null' && $response['images'] != 'null'){
        foreach($response['images'] as $key => $value){
            if(gettype($value) == 'string')
            $response['images'][$i] = json_decode($value,true);
            $i = $i+1;
        }
       
    }
        return $response;
    }

    

}

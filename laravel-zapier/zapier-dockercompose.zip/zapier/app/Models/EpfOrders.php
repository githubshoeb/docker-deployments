<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EpfOrders extends Model
{
    use HasFactory;
    protected $table = 'epf_orders';
    protected $primaryKey = "_airbyte_wc_orders_hashid";
    public $incrementing = false;
    public $keyType = 'string';
    protected $fillable = [
        'name',
        'billing_address',
        'line_items',
         'shipping_address',
         'tax_lines'
    ];

     /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'line_items' => 'json',
         'billing_address' => 'json',
         'shipping_address' => 'json',
          'tax_lines' => 'json',
          'customer' => 'json'
    ];

    public function lineItems(){
        return $this->hasMany(WooOrdersLineItems::class ,'_airbyte_wc_orders_hashid');
    }
}

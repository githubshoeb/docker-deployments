<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SpfDraftOrdersLineItems extends Model
{
    use HasFactory;

    protected $table = 'spf_draft_orders_line_items';
    #protected $primaryKey = "_airbyte_sf_draft_orders_hashid";
    protected $fillable = [
        'name',
        'billing_address',
        'line_items',
         'shipping_address',
         'tax_lines',
         '_airbyte_sf_draft_orders_hashid'
    ];

     /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'line_items' => 'json',
         'billing_address' => 'json',
         'shipping_address' => 'json',
          'tax_lines' => 'json',
          'customer' => 'json',
          '_airbyte_sf_draft_orders_hashid' =>"string"
    ];

   
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AirbyteTable extends Model
{
    use HasFactory;
    
    protected $table = 'airbyte_workspace_config';
    protected $fillable = [
        'workspace_id',
        'customer_id',
        'email_id',
        "profile_id",
        "connection_id"
    ];
}

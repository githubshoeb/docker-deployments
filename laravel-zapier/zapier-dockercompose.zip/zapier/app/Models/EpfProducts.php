<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Casts\Json;
class EpfProducts extends Model
{
    use HasFactory;

    protected $table = 'epf_products';
    protected $fillable = [
        'name',
        'slug',
        'images'
    ];

     /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'image' => Json::class,
        'images' => 'json',
    ];
    
    
}

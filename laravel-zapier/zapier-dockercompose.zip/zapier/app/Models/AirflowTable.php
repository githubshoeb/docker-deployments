<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AirflowTable extends Model
{
    use HasFactory;
    
    protected $table = 'airflow_dags';
    protected $fillable = [
        'customer_id',
        'email_id',
        "profile_id",
        "connection_id"
    ];
}

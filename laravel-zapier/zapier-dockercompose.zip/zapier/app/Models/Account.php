<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    protected $fillable = [
        'account_id',
        'name',
        'email',
        'first_name', // Add other fields as needed
        'last_name',
        'investor_name',
        'phone_number',
        'city',
        'state',
        'zip_code',
    ];
}

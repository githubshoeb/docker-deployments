#!/bin/sh

./run.sh

exec "php-fpm"
#apk add --no-cache zip libzip-dev librdkafka-dev git unzip wget autoconf
#apk add --no-cache ${PHPIZE_DEPS}
#pecl install rdkafka && docker-php-ext-enable rdkafka
